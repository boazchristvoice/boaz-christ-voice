BOAZ CHRIST VOICE WEBSITE

Connected social profiles:
YouTube: https://youtube.com/@boazchristvoice
Instagram: https://www.instagram.com/boazchristvoice/

Logo:
The uploaded Boaz Christ Voice logo has been cleaned/cropped and is included as logo.png.

Free hosting:
Upload all files in this folder to GitHub Pages, Netlify, or Cloudflare Pages.
